#include <Arduino.h>
#include <Wire.h>

#define Green 2
#define Yellow 3
#define Red 4
#define Slave_Address 0x42


unsigned long previousTime = 0;
unsigned long previousTimerecieve = 0;
unsigned long previousTimerequest = 0;

void receiveEvent(int readByte)
{
  unsigned long currentTime = millis();
  while (Wire.available()) {
    readByte = Wire.read();
    if (currentTime - previousTime >= 5000){
    Serial.print("I2C-Slave-receive : Empfangen: ");
    Serial.println(readByte);
    previousTime = currentTime;
    } 
  }
  
  if (currentTime - previousTimerecieve >= 5000){

    if (bitRead(readByte, 2))
    { 
      Serial.print("LED : ");
      Serial.print("Ampel schaltet Grün ein.\n");
    }
    else
    {
      Serial.print("LED : ");
      Serial.print("Ampel schaltet Grün aus.\n");
    }

    if (bitRead(readByte, 1))
    {
      Serial.print("LED : ");
      Serial.print("Ampel schaltet Gelb ein.\n");
    }
    else{
      Serial.print("LED : ");
      Serial.print("Ampel schaltet Gelb aus.\n");
     }
    
    if (bitRead(readByte, 0))
    {
      Serial.print("LED : ");
      Serial.print("Ampel schaltet Rot ein.\n");
    }
    else
    {
      Serial.print("LED : ");
      Serial.print("Ampel schaltet Rot aus.\n");
    }
    if (bitRead(readByte, 0) && bitRead(readByte, 1) && bitRead(readByte, 2))
    {
      Serial.print("LED : ");
      Serial.print("Ampel schaltet alle Farben ein.\n");
    }
    else if(!bitRead(readByte, 0) && !bitRead(readByte, 1) && !bitRead(readByte, 2))
    {
      Serial.print("LED : ");
      Serial.print("Ampel schaltet alle Farben aus.\n");
    }
    previousTimerecieve = currentTime;
  }
  
  if (bitRead(readByte, 2))
    {
      digitalWrite(Green, HIGH);
    }
    else
    {
      digitalWrite(Green, LOW);
    }

    if (bitRead(readByte, 1))
    {
      digitalWrite(Yellow, HIGH);
    }
    else
    {
      digitalWrite(Yellow, LOW);
    }
    
    if (bitRead(readByte, 0))
    {
      digitalWrite(Red, HIGH);
    }
    else
    {   
      digitalWrite(Red, LOW);
    }

    if(!bitRead(readByte, 0) && !bitRead(readByte, 1) && !bitRead(readByte, 2))
    {
      digitalWrite(Green, LOW);
      digitalWrite(Yellow, LOW);
      digitalWrite(Red, LOW);
    }
  }

  void requestEvent()
  {
    unsigned long currentTimerequest = millis();
    
    int Byte1 = 0;
    int Byte2 = 0;
    int Byte3 = 0;
    int sendByte;
    
    if (digitalRead(Green) == HIGH)
    {
      Byte1 = 0b00000100;
    }
    if(digitalRead(Yellow)== HIGH)
    {
      Byte2 = 0b00000010;
    }
    if(digitalRead(Red)== HIGH)
    {
      Byte3 = 0b00000001;
    }
    sendByte = Byte1 + Byte2 + Byte3;
    

    Wire.write(sendByte);
    
    if (currentTimerequest - previousTimerequest >= 5000)
    {
      Serial.print("I2C-Slave-receive : Abfrage erhalten.\n");
      if (bitRead(sendByte, 0) && bitRead(sendByte, 1) && bitRead(sendByte, 2))
      {
        Serial.print("I2C-Slave-transmit -> LED : ");
        Serial.print("Alle Farben sind an.\n");
      }
      else if(bitRead(sendByte,0) && bitRead(sendByte,1))
      {
        Serial.print("I2C-Slave-transmit -> LED : ");
        Serial.print("Rot und Gelb sind an.\n");
      }
      else if(bitRead(sendByte,0) && bitRead(sendByte,2))
      {
        Serial.print("I2C-Slave-transmit -> LED : ");
        Serial.print("Rot und Grün sind an.\n");
      }
      else if(bitRead(sendByte,1) && bitRead(sendByte,2))
      {
        Serial.print("I2C-Slave-transmit -> LED : ");
        Serial.print("Grün und Gelb sind an.\n");
      }
      else if(bitRead(sendByte,0))
      {
        Serial.print("I2C-Slave-transmit -> LED : ");
        Serial.print("Rot ist an.\n");
      }
      else if(bitRead(sendByte,1))
      {
        Serial.print("I2C-Slave-transmit -> LED : ");
        Serial.print("Gelb ist an.\n");
      }
      else if(bitRead(sendByte,2))
      {
        Serial.print("I2C-Slave-transmit -> LED : ");
        Serial.print("Grün ist an.\n");
      }
      previousTimerequest = currentTimerequest;
    }
    
  }

void setup() {
  pinMode(Green, OUTPUT);
  pinMode(Yellow, OUTPUT);
  pinMode(Red, OUTPUT);
  Wire.begin(Slave_Address);
  Wire.onReceive(receiveEvent);
  Wire.onRequest(requestEvent);
  Serial.begin(115200);
  delay(5000);
  Serial.println ("Slave, Adresse: 0x42, Gruppe: 02");
}





void loop() {
{  
  delay(100);
}
}

  
   



