#include <Arduino.h>
#include <Wire.h>
#define Green 2
#define Yellow 3
#define Red 4
int readByte;
void Aufruf(){
if (bitRead(readByte, 2))
  {

    digitalWrite(Green, HIGH);
  }
}
// function that executes whenever data is received from master
// this function is registered as an event, see setup()
void receiveEvent(int howMany)
{
  while(1 < Wire.available()) // loop through all but the last
  {
    char c = Wire.read(); // receive byte as a character
    Serial.print(c);         // print the character
  }
  int x = Wire.read();    // receive byte as an integer
  Serial.println(x);         // print the integer
  Aufruf();
  
}

void setup()
{
  pinMode(Green, OUTPUT);
  pinMode(Yellow, OUTPUT);
  pinMode(Red, OUTPUT);
  Wire.begin(0x42);                // join i2c bus with address #4
  Wire.onReceive(receiveEvent); // register event
  Serial.begin(115200);           // start serial for output
}
  
   

void loop()
{
//digitalWrite(Green, HIGH);
//digitalWrite(Yellow, HIGH);
digitalWrite(Red, HIGH);
  delay(100);
}

