#include <stm32f4xx.h>
#include <gpio.h>
#include <uart.h>
#include <i2c.h>
#include <exti.h>
#include <stdio.h>

#define slave_add 0x42 //empfängeradresse
uint8_t daten = 0b00000000;

void i2c_setup(){
    i2c_master_setup(I2C1, I2C_STANDARD);
}


int main(){

    i2c_setup();

while (true)
{
    i2c_master_transmit(I2C1, slave_add, &daten, sizeof(daten));
}



}
