# Changelog 

Keep track of changes, using SemVer.

## 0.0.1 (upcomming)

- Added module for gpio handling.
- Added module to use systick timer for `delay_ms`.
- Added module for initalising the uart pheripherals
- Added module for external interrupts
- Added module for setting up timers.
