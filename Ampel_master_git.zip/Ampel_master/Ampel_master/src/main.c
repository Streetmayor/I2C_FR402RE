#include <stm32f4xx.h>
#include <gpio.h>
#include <uart.h>
#include <i2c.h>
#include <exti.h>
#include <delay.h>
#include <stdio.h>

//Zuweisung der Eingänge
#define taster_PC0_rot 0 //PC0
#define taster_PC1_gelb 1 //PC1
#define taster_PC2_gruen 2 //PC2
#define taster_PC3_alle 3 //PC3
#define taster_PC4_daten_anfordern 4 //PC4
#define slave_add 0x42 //empfängeradresse

#define print_rate 10000 // Zeit für Augabe der Prints

bool rot = false;
int rotb = 0b00000001;
bool gelb = false;
int gelbb = 0b00000010;
bool gruen = false;
int gruenb = 0b00000100;
bool alle = false;
int alleb = 0b00000111;
bool anforderungDaten = false;
int anforderungDatenb = 0b00001000;

// Variable für Daten senden
uint8_t daten = 0b00000000;

//Variable für Empfangene Daten
uint8_t recdaten = 0b00000000;


void taster_setup(){
    gpio_enable_port_clock(GPIOC);
    gpio_set_mode(GPIOC, taster_PC0_rot, INPUT);
    gpio_set_mode(GPIOC, taster_PC1_gelb, INPUT);
    gpio_set_mode(GPIOC, taster_PC2_gruen, INPUT);
    gpio_set_mode(GPIOC, taster_PC3_alle, INPUT);
    gpio_set_mode(GPIOC, taster_PC4_daten_anfordern, INPUT);
}

void uart_setup_funk(){
    uart_setup(USART2, 115200);
}

void interrupt_setup(){
    exti_enable_syscfg_clock();

    exti_set_source(EXTI_LINE_0, GPIOC);
    exti_set_source(EXTI_LINE_1, GPIOC);
    exti_set_source(EXTI_LINE_2, GPIOC);
    exti_set_source(EXTI_LINE_3, GPIOC);
    exti_set_source(EXTI_LINE_4, GPIOC);

    exti_enable_irq(EXTI_LINE_0);
    exti_enable_irq(EXTI_LINE_1);
    exti_enable_irq(EXTI_LINE_2);
    exti_enable_irq(EXTI_LINE_3);
    exti_enable_irq(EXTI_LINE_4);

    exti_set_trigger_edge(EXTI_LINE_0, EXTI_RISING_EDGE);
    exti_set_trigger_edge(EXTI_LINE_1, EXTI_RISING_EDGE);
    exti_set_trigger_edge(EXTI_LINE_2, EXTI_RISING_EDGE);
    exti_set_trigger_edge(EXTI_LINE_3, EXTI_RISING_EDGE);
    exti_set_trigger_edge(EXTI_LINE_4, EXTI_RISING_EDGE);

    NVIC_EnableIRQ(EXTI0_IRQn);
    NVIC_EnableIRQ(EXTI1_IRQn);
    NVIC_EnableIRQ(EXTI2_IRQn);
    NVIC_EnableIRQ(EXTI3_IRQn);
    NVIC_EnableIRQ(EXTI4_IRQn);

}

void i2c_setup(){
    i2c_master_setup(I2C1, I2C_STANDARD);
}

void datenSendenAuslesen(){
     switch (daten)
    {
    case 0b00000000:
        printf("I2C: Master transmit -> LED: Alle LED´s auschalten\n");
        break;
    case 0b00000001:
        printf("I2C: Master transmit -> LED: Die Rote LED einschalten\n");
        break;
    case 0b00000010:
        printf("I2C: Master transmit -> LED: Die Gelbe LED einschalten\n");
        break;
    case 0b00000100:
        printf("I2C: Master transmit -> LED: Die Grüne LED einschalten\n");
        break;
    case 0b00000011:
        printf("I2C: Master transmit -> LED: Die Rote und Gelbe LED einschalten\n");
        break;
    case 0b00000110:
        printf("I2C: Master transmit -> LED: Die Gelbe und Grüne LED einschalten\n");
        break;
    case 0b00000101:
        printf("I2C: Master transmit -> LED: Die Rote und Grüne LED einschalten\n");
        break;
    case 0b00000111:
        printf("I2C: Master transmit -> LED: Alle LED´s eingeschalten\n");
        break;
    }
}

void recDatenAuslesen(){
    printf("Daten: %i", recdaten);
    switch (recdaten)
    {
    case 0b00000000:
        printf("I2C: Slave recive -> LED: Alle LED´s sind ausgeschalten\n");
        break;
    case 0b00000001:
        printf("I2C: Slave recive -> LED: Die Rote LED ist eingeschalten\n");
        break;
    case 0b00000010:
        printf("I2C: Slave recive -> LED: Die Gelbe LED ist eingeschalten\n");
        break;
    case 0b00000100:
        printf("I2C: Slave recive -> LED: Die Grüne LED ist eingeschalten\n");
        break;
    case 0b00000011:
        printf("I2C: Slave recive -> LED: Die Rote und Gelbe LED ist eingeschalten\n");
        break;
    case 0b00000110:
        printf("I2C: Slave recive -> LED: Die Gelbe und Grüne LED ist eingeschalten\n");
        break;
    case 0b00000101:
        printf("I2C: Slave recive -> LED: Die Rote und Grüne LED ist eingeschalten\n");
        break;
    case 0b00000111:
        printf("I2C: Slave recive -> LED: Alle LED´s sind eingeschalten\n");
        break;
    }
}

int main(){

    
    __disable_irq();
    systick_init();
    DWT_init();
    taster_setup();
    uart_setup_funk();
    interrupt_setup();
    i2c_setup();
    __enable_irq();
    
    uint32_t previous_time_recive = DWT_millis();
    uint32_t previous_time_send = DWT_millis();
    systick_delay_ms(5000);
    printf("Master, Gruppe: 02\n");
while (true)
{
    uint32_t current_time = DWT_millis();

    if(!anforderungDaten){

        i2c_master_transmit(I2C1, slave_add, &daten, 1);
    
        if((current_time - previous_time_send) >= print_rate){
            datenSendenAuslesen();
            previous_time_send = current_time;
        }
        
    }
    if (anforderungDaten){

        i2c_master_receive(I2C1, slave_add, &recdaten, sizeof(recdaten));
    
        if((current_time - previous_time_recive) >= print_rate){
            recDatenAuslesen();
            previous_time_recive = current_time;
        } 
        
    }
    systick_delay_ms(100);
}

}

int _write(int fd, char *ptr, int len){

    uint32_t size = len;

    while (len-- > 0){
        uart_write_byte(USART2,*(ptr++));
    }

    return size;
}

//Interrupt für Taster -> Rote LED
void EXTI0_IRQHandler(void){
    if(exti_is_irq_pending(EXTI_LINE_0)){
        if(anforderungDaten){
            printf("I2C: Master recive -> BTN: Rote LED schalten -> Bitte BTN 'anforderungDaten' drücken für Master transmit \n");
        }
        else{
            
            if(!rot){
                daten = daten | rotb;
                printf("BTN: Rote LED  einschalten\n");
            
            }
            if(rot){
                daten = daten & (~rotb);
                
                printf("BTN: Rote LED  ausschalten\n");
            
            }
            rot =! rot;
        }

        exti_reset_pending_bit(EXTI_LINE_0);
    }
}

//Interrupt für Taster -> Gelbe LED
void EXTI1_IRQHandler(void){
    if(exti_is_irq_pending(EXTI_LINE_1)){
         if(anforderungDaten){
            printf("I2C: Master recive -> BTN: Gelbe LED schalten -> Bitte BTN 'anforderungDaten' drücken für Master transmit\n");
        }
        else{
            
            if(!gelb){
                daten = daten | gelbb;
                printf("BTN: Gelbe LED  einschalten\n");

            }
            if(gelb){
                daten = daten & (~gelbb);
                
                printf("BTN: Gelbe LED  ausschalten\n");
                
            }
            gelb =! gelb;
        }
        
        exti_reset_pending_bit(EXTI_LINE_1);
    }
}

//Interrupt für Taster -> Grüne LED
void EXTI2_IRQHandler(void){
    if(exti_is_irq_pending(EXTI_LINE_2)){
        if(anforderungDaten){
            printf("I2C: Master recive -> BTN: Grüne LED schalten -> Bitte BTN 'anforderungDaten' drücken für Master transmit\n");
        }
        else{
            
            if(!gruen){
                daten = daten | gruenb;
                printf("BTN: Grüne LED  einschalten\n");
                
            }
            if(gruen){
                daten = daten & (~gruenb);
                
                printf("BTN: Grüne LED  ausschalten\n");
                
            }
            gruen =! gruen;
        }
        
        exti_reset_pending_bit(EXTI_LINE_2);
    }
}

//Interrupt für Taster -> Alle LED´s schalten
void EXTI3_IRQHandler(void){
    if(exti_is_irq_pending(EXTI_LINE_3)){
        if(anforderungDaten){
            printf("I2C: Master recive -> BTN: alle LED´s schalten -> Bitte BTN 'anforderungDaten' drücken für Master transmit\n");
        }
        else{
            
            if(!alle){
                daten = daten | alleb;
                printf("BTN: Rote LED´s  einschalten\n");
                
            }
            if(alle){
                daten = daten & (~alleb);
                
                printf("BTN: Alle LED´s  ausschalten\n");
                
            }
            alle =! alle;
        }
        
        exti_reset_pending_bit(EXTI_LINE_3);
    }
}

//Interrupt für Taster -> Daten senden oder Daten vom Slave Empfangen
void EXTI4_IRQHandler(void){
    
    if(exti_is_irq_pending(EXTI_LINE_4)){
        if(!anforderungDaten){
            daten = daten | anforderungDatenb;
            printf("I2C: Master transmit -> BTN: Daten vom Slave empfangen\n");
            
        }
        if(anforderungDaten){
            daten = daten & (~anforderungDatenb);
            
            printf("I2C: Master transmit -> BTN: Daten zum Slave senden\n");
            
        }
        anforderungDaten =! anforderungDaten;
        exti_reset_pending_bit(EXTI_LINE_4);
    }
}